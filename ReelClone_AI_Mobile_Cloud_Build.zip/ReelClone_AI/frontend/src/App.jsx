import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Upload, Video, ImagePlus, WandSparkles, Download, Play, Clock3, ShieldCheck, Sparkles, RefreshCw, AlertCircle, CheckCircle2, Film, UserRound, Settings2 } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000';
const MAX_VIDEO = 100 * 1024 * 1024;
const MAX_SECONDS = 15;

function formatSize(n){ return n < 1024*1024 ? `${(n/1024).toFixed(0)} KB` : `${(n/1024/1024).toFixed(1)} MB`; }

function UploadPanel({title,subtitle,accept,icon:Icon,file,onFile,preview,kind}) {
  const input = useRef(null);
  return <section className="panel upload-panel">
    <div className="panel-heading"><div className="iconbox"><Icon size={20}/></div><div><h3>{title}</h3><p>{subtitle}</p></div></div>
    <input ref={input} type="file" accept={accept} hidden onChange={e=>onFile(e.target.files?.[0] || null)}/>
    {!file ? <button className="dropzone" onClick={()=>input.current?.click()}>
      <div className="upload-circle"><Upload size={22}/></div><b>फाइल चुनें या यहाँ अपलोड करें</b><span>{accept}</span>
    </button> : <div className="preview-wrap">
      {kind==='video' ? <video src={preview} controls playsInline /> : <img src={preview} alt="अपलोड की गई फोटो"/>}
      <div className="file-meta"><b>{file.name}</b><span>{formatSize(file.size)}</span></div>
      <button className="text-button" onClick={()=>{onFile(null); if(input.current) input.current.value='';}}>बदलें</button>
    </div>}
  </section>
}

export default function App(){
  const [video,setVideo]=useState(null), [photo,setPhoto]=useState(null);
  const [videoUrl,setVideoUrl]=useState(''), [photoUrl,setPhotoUrl]=useState('');
  const [consent,setConsent]=useState(false), [audio,setAudio]=useState(true);
  const [job,setJob]=useState(null), [busy,setBusy]=useState(false), [error,setError]=useState('');
  const [mode,setMode]=useState('full_body');
  const [apiOnline,setApiOnline]=useState(false);

  useEffect(()=>{ fetch(`${API}/api/health`).then(r=>r.ok&&setApiOnline(true)).catch(()=>setApiOnline(false)); },[]);
  useEffect(()=>{ if(video){const u=URL.createObjectURL(video);setVideoUrl(u);return()=>URL.revokeObjectURL(u)}setVideoUrl('');},[video]);
  useEffect(()=>{ if(photo){const u=URL.createObjectURL(photo);setPhotoUrl(u);return()=>URL.revokeObjectURL(u)}setPhotoUrl('');},[photo]);

  const videoDuration = useMemo(()=>null,[video]);
  function chooseVideo(f){
    setError(''); setJob(null);
    if(!f){setVideo(null);return;}
    if(!['video/mp4','video/quicktime'].includes(f.type)){setError('कृपया MP4 या MOV वीडियो चुनें।');return;}
    if(f.size>MAX_VIDEO){setError('वीडियो 100 MB से छोटा होना चाहिए।');return;}
    setVideo(f);
  }
  function choosePhoto(f){
    setError(''); setJob(null);
    if(!f){setPhoto(null);return;}
    if(!['image/jpeg','image/png'].includes(f.type)){setError('कृपया JPG या PNG फोटो चुनें।');return;}
    if(f.size>15*1024*1024){setError('फोटो 15 MB से छोटी होनी चाहिए।');return;}
    setPhoto(f);
  }
  async function generate(){
    setError('');
    if(!video||!photo){setError('पहले वीडियो और फोटो दोनों अपलोड करें।');return;}
    if(!consent){setError('आगे बढ़ने के लिए फोटो/वीडियो उपयोग की अनुमति की पुष्टि करें।');return;}
    setBusy(true);setJob(null);
    try{
      const fd=new FormData();fd.append('video',video);fd.append('photo',photo);fd.append('mode',mode);fd.append('preserve_audio',String(audio));
      const res=await fetch(`${API}/api/generate`,{method:'POST',body:fd});
      const data=await res.json(); if(!res.ok) throw new Error(data.detail||'प्रोजेक्ट शुरू नहीं हो पाया।');
      setJob(data);
    }catch(e){setError(`Backend से कनेक्शन नहीं हुआ: ${e.message}. क्या Python सर्वर चालू है?`);}
    finally{setBusy(false);}
  }
  useEffect(()=>{
    if(!job?.id || job.status==='completed' || job.status==='failed') return;
    const timer=setInterval(async()=>{
      try{const r=await fetch(`${API}/api/jobs/${job.id}`);if(r.ok)setJob(await r.json());}catch{}
    },1800);
    return()=>clearInterval(timer);
  },[job?.id,job?.status]);

  return <div className="app-shell">
    <header className="topbar"><div className="brand"><div className="brand-mark"><Sparkles size={20}/></div><div><strong>ReelClone <span>AI</span></strong><small>आपका AI Reel Studio</small></div></div><div className="top-actions"><span className={`server-pill ${apiOnline?'online':''}`}><i/>{apiOnline?'सर्वर कनेक्टेड':'डेमो / सर्वर ऑफलाइन'}</span><button className="avatar">RC</button></div></header>
    <main className="main">
      <section className="hero"><div className="eyebrow"><Sparkles size={14}/> AI VIDEO TRANSFORMATION STUDIO</div><h1>अपनी फोटो को Reel का <em>हीरो</em> बनाओ।</h1><p>एक reference वीडियो और एक अनुमति-प्राप्त फोटो अपलोड करें। AI motion transfer से नया वीडियो बनाने की तैयारी करें।</p><div className="hero-tags"><span><ShieldCheck size={14}/> पहचान की सुरक्षा</span><span><Film size={14}/> MP4 / MOV</span><span><Clock3 size={14}/> 15 सेकंड तक</span></div></section>

      <div className="section-title"><div><span className="step">01</span><h2>अपनी फाइलें अपलोड करें</h2></div><span className="muted">दोनों जरूरी हैं</span></div>
      <div className="upload-grid">
        <UploadPanel title="Reference Reel" subtitle="जिस वीडियो का motion इस्तेमाल करना है" accept="MP4 या MOV • 100 MB तक" icon={Video} file={video} onFile={chooseVideo} preview={videoUrl} kind="video"/>
        <UploadPanel title="Character Photo" subtitle="जिस व्यक्ति को वीडियो में दिखाना है" accept="JPG या PNG • 15 MB तक" icon={ImagePlus} file={photo} onFile={choosePhoto} preview={photoUrl} kind="image"/>
      </div>

      <section className="panel settings">
        <div className="section-title compact"><div><span className="step">02</span><h2>वीडियो सेटिंग्स</h2></div><Settings2 size={19}/></div>
        <label className="field-label">क्लोन मोड</label>
        <div className="mode-grid">
          <button className={`mode-card ${mode==='full_body'?'selected':''}`} onClick={()=>setMode('full_body')}><UserRound/><b>Full Body Clone</b><small>बॉडी मूवमेंट + चेहरे के भाव</small></button>
          <button className={`mode-card ${mode==='face_expression'?'selected':''}`} onClick={()=>setMode('face_expression')}><Sparkles/><b>Face & Expression</b><small>चेहरा और एक्सप्रेशन प्राथमिक</small></button>
        </div>
        <label className="toggle-row"><span><b>Original audio रखना है</b><small>यदि मॉडल और प्रोसेसिंग इसकी अनुमति दें</small></span><input type="checkbox" checked={audio} onChange={e=>setAudio(e.target.checked)}/></label>
        <label className="toggle-row consent"><span><b>मेरी अनुमति की पुष्टि</b><small>मेरे पास अपलोड की गई फोटो और वीडियो इस्तेमाल करने का अधिकार/अनुमति है।</small></span><input type="checkbox" checked={consent} onChange={e=>setConsent(e.target.checked)}/></label>
        {error&&<div className="error"><AlertCircle size={17}/>{error}</div>}
        <button className="generate" disabled={busy||!video||!photo||!consent} onClick={generate}>{busy?<><RefreshCw className="spin"/> शुरू हो रहा है...</>:<><WandSparkles/> AI Reel बनाना शुरू करें <span>→</span></>}</button>
        <p className="fineprint">नोट: अभी यह MVP है। असली AI वीडियो जनरेशन के लिए GPU inference provider जोड़ना होगा।</p>
      </section>

      <section className="result-section"><div className="section-title"><div><span className="step">03</span><h2>आपका रिजल्ट</h2></div></div>
        {!job ? <div className="empty-result"><div className="empty-icon"><Play size={25}/></div><b>आपका नया Reel यहाँ दिखाई देगा</b><p>फाइलें अपलोड करके generation शुरू करें।</p></div> :
        <div className="panel job-card"><div className="job-head"><div><b>Generation Job</b><small>ID: {job.id}</small></div><span className={`status ${job.status}`}>{job.status==='queued'?'कतार में':job.status==='processing'?'प्रोसेसिंग':job.status==='completed'?'पूरा हुआ':job.status==='failed'?'असफल':'डेमो'}</span></div>
          <div className="progress"><i style={{width:`${job.progress||0}%`}}/></div><p className="job-message">{job.message}</p>
          {job.demo&&<div className="notice"><AlertCircle size={17}/> यह Demo Job है। असली वीडियो तैयार नहीं हुआ क्योंकि AI मॉडल अभी कनेक्ट नहीं है।</div>}
          {job.result_url&&<a className="download" href={`${API}${job.result_url}`} download><Download size={17}/> MP4 डाउनलोड करें</a>}
        </div>}
      </section>
      <footer><span>ReelClone AI · MVP 0.1</span><span>अपलोड की गई फाइलें केवल स्थानीय backend पर रखी जाती हैं।</span></footer>
    </main>
  </div>
}
