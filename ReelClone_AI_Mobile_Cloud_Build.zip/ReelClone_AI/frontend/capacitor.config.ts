import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.reelclone.ai',
  appName: 'ReelClone AI',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
