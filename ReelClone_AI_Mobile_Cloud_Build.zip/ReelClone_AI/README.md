# ReelClone AI — Hindi MVP

यह एक शुरुआती, चलने योग्य Web App प्रोजेक्ट है। इसमें वीडियो और फोटो अपलोड, प्रीव्यू,
बेसिक validation, generation job status और demo result flow शामिल हैं।

**महत्वपूर्ण:** इस पैकेज में असली AI motion-transfer मॉडल शामिल/होस्ट नहीं है। AI provider
adapter जानबूझकर स्पष्ट रूप से `not_configured` लौटाता है। इसलिए ऐप demo mode में चलता है;
यह नकली AI output को असली generated video बताकर पेश नहीं करता। वास्तविक full-body motion
transfer के लिए संगत GPU inference endpoint/model और उसकी credentials जोड़नी होंगी।

## चलाने का तरीका

### 1) Backend (Python 3.10+)

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Backend: http://localhost:8000  
API docs: http://localhost:8000/docs

### 2) Frontend (Node.js 18+)

दूसरे terminal में:

```bash
cd frontend
npm install
npm run dev
```

फिर Vite द्वारा दिखाया गया local URL खोलें (आमतौर पर http://localhost:5173)।

## क्या काम करता है?

- हिंदी responsive dashboard
- MP4 / MOV वीडियो अपलोड और वीडियो preview
- JPG / PNG फोटो अपलोड और फोटो preview
- वीडियो duration और file-size validation (MVP limits: 15 sec, 100 MB)
- generation job create और status polling
- demo mode में साफ-साफ demo status
- consent checkbox
- FastAPI upload/job API

## असली AI जोड़ने के लिए

`backend/app/providers.py` में `MotionTransferProvider` adapter लागू करें। इसे किसी ऐसे
inference endpoint से जोड़ें जो आपके चुने हुए motion-transfer मॉडल के अनुरूप हो। फिर
`backend/.env.example` की settings भरें और `main.py` में provider को enable करें।
GPU सेवा, मॉडल लाइसेंस, compute limits और API शुल्क provider के अनुसार अलग होंगे।

## सुरक्षा नोट

- केवल अपनी फोटो या स्पष्ट अनुमति वाली फोटो अपलोड करें।
- यह MVP local development के लिए है; सार्वजनिक deployment से पहले authentication,
  rate limiting, persistent job queue, object storage, malware scanning, HTTPS और
  automatic deletion policy जोड़ें।
- स्थानीय upload फ़ाइलें `backend/uploads/` में रखी जाती हैं।


## मोबाइल पर इस्तेमाल (Web App / PWA)

1. Frontend को HTTPS hosting पर deploy करें और `VITE_API_URL` को deployed backend URL पर सेट करें।
2. मोबाइल Chrome में उस HTTPS URL को खोलें।
3. Chrome मेनू → **Add to Home screen** या **Install app** चुनें।
4. आइकन से ReelClone AI ऐप-जैसे खुलेगा।

PWA का shell installable है; offline में AI generation नहीं चलेगा। Backend online होना जरूरी है।

## Android APK बनाना

APK बनाने के लिए Android Studio वाला कंप्यूटर या cloud Android build environment चाहिए।
सिर्फ फोन पर ZIP खोलकर signed APK बनाना भरोसेमंद/सरल नहीं है।

1. `frontend` फ़ोल्डर में:
   ```bash
   npm install
   ```
2. Android Studio और Android SDK वाले environment में:
   ```bash
   npx cap add android
   npm run android:sync
   npx cap open android
   ```
3. Android Studio में Build → Build Bundle(s) / APK(s) → Build APK(s) चुनें।
4. रिलीज़ के लिए अपना signing key बनाकर signed APK तैयार करें।

**महत्वपूर्ण:** `VITE_API_URL` में public HTTPS backend URL होना चाहिए। `localhost` मोबाइल APK के अंदर तुम्हारे फोन का backend नहीं होगा। AI provider integration और GPU inference अलग से deploy करना होगा।


## बिना कंप्यूटर के APK बनाना (GitHub Actions Cloud Build)

यह प्रोजेक्ट `.github/workflows/android-apk.yml` workflow के साथ आता है।
इसे GitHub repository की `main` branch पर upload करने के बाद:
1. GitHub में repository खोलें → Actions.
2. "Build ReelClone AI Android APK" चुनें → Run workflow.
3. Build पूरा होने पर workflow run खोलें → Artifacts → `ReelClone-AI-debug-APK` डाउनलोड करें।
4. ZIP extract करके `app-debug.apk` फोन में install करें। Android पूछे तो केवल भरोसेमंद source के लिए install permission दें।

GitHub Actions की उपलब्धता/मिनट आपके GitHub plan और usage पर निर्भर है।
APK में सही backend URL डालने के लिए repository Settings → Secrets and variables → Actions में
`VITE_API_URL` नाम का Repository Secret जोड़ें, जिसकी value deployed HTTPS API URL हो।
Secret न देने पर frontend default localhost इस्तेमाल करेगा और फोन पर API काम नहीं करेगा।

## Mobile browser workflow

GitHub mobile website पर नया repository बनाएं। फोन में ZIP extract करने के लिए Files app का
Extract विकल्प इस्तेमाल करें। GitHub repository में project files/folders upload करने के लिए
browser का Desktop site विकल्प मदद कर सकता है। `.github/workflows/android-apk.yml` path मौजूद
होना चाहिए; GitHub Actions tab में workflow दिखेगा।
