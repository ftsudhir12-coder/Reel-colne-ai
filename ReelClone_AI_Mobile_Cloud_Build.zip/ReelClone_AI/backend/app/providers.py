"""AI provider boundary. Implement a real GPU inference integration here."""
from dataclasses import dataclass

@dataclass
class ProviderResult:
    configured: bool
    message: str

class MotionTransferProvider:
    def __init__(self):
        # Deliberately disabled until a real, compatible inference endpoint is configured.
        self.endpoint = None

    def is_configured(self) -> bool:
        return bool(self.endpoint)

    async def generate(self, video_path: str, photo_path: str, mode: str, preserve_audio: bool):
        raise NotImplementedError(
            "AI motion-transfer provider is not configured. Connect a compatible GPU inference endpoint."
        )
