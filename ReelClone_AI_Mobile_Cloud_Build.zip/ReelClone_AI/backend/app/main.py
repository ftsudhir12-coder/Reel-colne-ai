from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
from uuid import uuid4
import shutil, os, asyncio
from typing import Dict

BASE = Path(__file__).resolve().parents[1]
UPLOAD_DIR = BASE / os.getenv("UPLOAD_DIR", "uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
MAX_VIDEO = int(os.getenv("MAX_VIDEO_MB", "100")) * 1024 * 1024
MAX_PHOTO = int(os.getenv("MAX_PHOTO_MB", "15")) * 1024 * 1024
jobs: Dict[str, dict] = {}

app = FastAPI(title="ReelClone AI API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

async def save_limited(upload: UploadFile, destination: Path, limit: int):
    total = 0
    try:
        with destination.open("wb") as out:
            while chunk := await upload.read(1024 * 1024):
                total += len(chunk)
                if total > limit:
                    out.close()
                    destination.unlink(missing_ok=True)
                    raise HTTPException(413, "फाइल निर्धारित आकार से बड़ी है।")
                out.write(chunk)
    finally:
        await upload.close()
    if total == 0:
        destination.unlink(missing_ok=True)
        raise HTTPException(400, "खाली फाइल अपलोड नहीं की जा सकती।")

@app.get("/api/health")
async def health():
    return {"ok": True, "service": "ReelClone AI API", "ai_provider": "not_configured", "mode": "demo"}

@app.post("/api/generate")
async def generate(video: UploadFile = File(...), photo: UploadFile = File(...), mode: str = Form("full_body"), preserve_audio: bool = Form(True)):
    video_ext = Path(video.filename or "").suffix.lower()
    photo_ext = Path(photo.filename or "").suffix.lower()
    if video_ext not in {".mp4", ".mov"}:
        raise HTTPException(415, "वीडियो केवल MP4 या MOV होना चाहिए।")
    if photo_ext not in {".jpg", ".jpeg", ".png"}:
        raise HTTPException(415, "फोटो केवल JPG या PNG होनी चाहिए।")
    if mode not in {"full_body", "face_expression"}:
        raise HTTPException(400, "अमान्य क्लोन मोड।")
    job_id = str(uuid4())
    vpath = UPLOAD_DIR / f"{job_id}_reference{video_ext}"
    ppath = UPLOAD_DIR / f"{job_id}_character{photo_ext}"
    try:
        await save_limited(video, vpath, MAX_VIDEO)
        await save_limited(photo, ppath, MAX_PHOTO)
    except Exception:
        vpath.unlink(missing_ok=True); ppath.unlink(missing_ok=True)
        raise
    jobs[job_id] = {
        "id": job_id, "status": "processing", "progress": 8,
        "message": "फाइलें सुरक्षित रूप से प्राप्त हुईं। AI provider की जाँच हो रही है।",
        "demo": True, "result_url": None
    }
    # Honest MVP behavior: no fabricated output when no model is connected.
    asyncio.create_task(mark_demo(job_id))
    return jobs[job_id]

async def mark_demo(job_id: str):
    await asyncio.sleep(1.5)
    if job_id in jobs:
        jobs[job_id].update({
            "status": "failed", "progress": 0, "demo": True,
            "message": "AI मॉडल कनेक्ट नहीं है। असली वीडियो बनाने के लिए GPU inference provider जोड़ें।"
        })

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job नहीं मिला।")
    return jobs[job_id]

@app.get("/")
async def root():
    return {"message": "ReelClone AI API चालू है", "docs": "/docs"}
